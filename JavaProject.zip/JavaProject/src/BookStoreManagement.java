import java.util.ArrayList;
import java.util.Scanner;

class Book {
    private String title;
    private String author;
    private String isbn;
    private double price;
    private String section;

    public Book(String title, String author, String isbn, double price, String section) {
        this.title = title;
        this.author = author;
        this.isbn = isbn;
        this.price = price;
        this.section = section;
    }

    public String getTitle() {
        return title;
    }

    public String getIsbn() {
        return isbn;
    }

    public void displayBook() {
        System.out.println("Title: " + title + ", Author: " + author + ", ISBN: " + isbn + ", Price: ₹" + price);
        System.out.println("Section: " + section);
    }
}

class SpecialEditionBook extends Book {
    private boolean limitedEdition;
    private String extraContent;

    public SpecialEditionBook(String title, String author, String isbn, double price, String section, boolean limitedEdition, String extraContent) {
        super(title, author, isbn, price, section);
        this.limitedEdition = limitedEdition;
        this.extraContent = extraContent;
    }


    public void displayBook() {
        super.displayBook();
        System.out.println("Limited Edition: " + (limitedEdition ? "Yes" : "No"));
        System.out.println("Extra Content: " + extraContent);
    }
}

class BookStore {
    private ArrayList<Book> books;

    public BookStore() {
        books = new ArrayList<>();
        initializeBooks();
    }

    private void initializeBooks() {
        books.add(new Book("To Kill a Mockingbird", "Harper Lee", "9780060935467", 599, "Classics"));
        books.add(new Book("1984", "George Orwell", "9780451524935", 620, "Dystopian"));
        books.add(new SpecialEditionBook("The Great Gatsby", "F. Scott Fitzgerald", "9780743273565", 1000, "Classics", true, "Illustrated edition"));
        books.add(new Book("Pride and Prejudice", "Jane Austen", "9780141040349", 699, "Romance"));
        books.add(new Book("The Catcher in the Rye", "J.D. Salinger", "9780316769488", 499, "Classics"));
        books.add(new SpecialEditionBook("The Hobbit", "J.R.R. Tolkien", "9780547928227", 1200, "Fantasy", true, "Author's notes included"));
        books.add(new Book("Fahrenheit 451", "Ray Bradbury", "9781451673319", 600, "Dystopian"));
    }

    public void addBook(Book book) {
        books.add(book);
        System.out.println("Book added successfully!");
    }

    public void viewBooks() {
        if (books.isEmpty()) {
            System.out.println("No books available in the store.");
            return;
        }
        else {
            System.out.println("Books available in the store:");
            for (Book book : books) {
                book.displayBook();
                System.out.println();
            }
        }
    }

    public void searchBookByTitle(String title) {
        boolean found = false;
        for (Book book : books) {
            if (book.getTitle().equalsIgnoreCase(title)) {
                book.displayBook();
                found = true;
                break;
            }
        }
        if (!found) {
            System.out.println("Book with title \"" + title + "\" not found.");
        }
    }

    public void deleteBook(String isbn) {
        boolean removed = books.removeIf(book -> book.getIsbn().equals(isbn));
        if (removed) {
            System.out.println("Book removed successfully!");
        } else {
            System.out.println("Book with ISBN \"" + isbn + "\" not found.");
        }
    }
}

public class BookStoreManagement {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        BookStore bookStore = new BookStore();

        int choice = 0;
        while (choice != 5) {
            System.out.println("\n--- Book Store Management System ---");
            System.out.println("1. Add a Book");
            System.out.println("2. View All Books");
            System.out.println("3. Search Book by Title");
            System.out.println("4. Delete Book by ISBN");
            System.out.println("5. Exit");
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    System.out.print("Enter title: ");
                    String title = scanner.nextLine();
                    System.out.print("Enter author: ");
                    String author = scanner.nextLine();
                    System.out.print("Enter ISBN: ");
                    String isbn = scanner.nextLine();
                    System.out.print("Enter price: ");
                    double price = scanner.nextDouble();
                    scanner.nextLine();
                    System.out.print("Enter section: ");
                    String section = scanner.nextLine();
                    System.out.print("Is this a limited edition (true/false): ");
                    boolean limitedEdition = scanner.nextBoolean();
                    scanner.nextLine();
                    if (limitedEdition) {
                        System.out.print("Enter extra content description: ");
                        String extraContent = scanner.nextLine();
                        Book specialBook = new SpecialEditionBook(title, author, isbn, price, section, limitedEdition, extraContent);
                        bookStore.addBook(specialBook);
                    } else {
                        Book newBook = new Book(title, author, isbn, price, section);
                        bookStore.addBook(newBook);
                    }
                    break;

                case 2:
                    bookStore.viewBooks();
                    break;

                case 3:
                    System.out.print("Enter title to search: ");
                    String searchTitle = scanner.nextLine();
                    bookStore.searchBookByTitle(searchTitle);
                    break;

                case 4:
                    System.out.print("Enter ISBN to delete: ");
                    String deleteIsbn = scanner.nextLine();
                    bookStore.deleteBook(deleteIsbn);
                    break;

                case 5:
                    System.out.println("Exiting Book Store Management System. Goodbye!");
                    break;

                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }
}
